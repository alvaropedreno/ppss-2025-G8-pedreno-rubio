package ppss;

public class ButacasException extends Exception {
    public ButacasException() {
    }

    public ButacasException(String message) {
        super(message);
    }
}
